document.getElementById('fetch').addEventListener('click', () => {
  chrome.runtime.sendMessage({action: "fetchData"});
});